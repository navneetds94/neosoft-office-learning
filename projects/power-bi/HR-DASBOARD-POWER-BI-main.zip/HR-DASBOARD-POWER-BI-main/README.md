# HR-DASBOARD-POWER-BI
## Analytical Approach:-
1. unpivot columns 2. create new messures 3. create a dynamic dashboard 4.  create columns by using DAX
## KPI:- 
1.Over All Present in percentage 2. Work From Home percentage 3. Sick Leave percentage 4. present of a one employee In percentage 5.Monthly Present percentage
## insights :- 
1. Most Pepole Present on Monday 2. Most Work From Home on Friday 3. In april Month Presents Are declined
